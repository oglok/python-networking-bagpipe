=====
Usage
=====

To use networking-bagpipe in a project::

    import networking_bagpipe
