============
Installation
============

At the command line::

    $ pip install networking-bagpipe

Or, if you have virtualenvwrapper installed::

    $ mkvirtualenv networking-bagpipe
    $ pip install networking-bagpipe
